// CSC 118
// M1LAB - Apple slaes
// Bettina Papenfus
// January 23, 2020 

//print("Hello world")
// declare variables
var name: String
name = "Jane Smith"
let price = 0.25
var numApples = 255
//print('Welcome to',"Jane Smith's","apple farm")
print("Welcome to \(name)'s apple farm")
//print("Apples are $",0.25)
// PUT NUMBER OF APPLES MESSAGE HERE
print("Apples are $\(price) each,")
print("If you would like to purchase all \(numApples) the price would be $\(total)")

// find the total
let total = (price) * Double(numApples)
print("total is $\(total)")
